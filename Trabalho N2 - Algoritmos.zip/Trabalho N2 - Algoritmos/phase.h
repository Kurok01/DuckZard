#ifndef PHASE_H
#define PHASE_H

int phase1();
int phase2();
int phase3();
int phase4();
int finalPhase();

#endif
