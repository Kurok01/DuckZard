#ifndef STATISTICS_H
#define STATISTICS_H

void saveData (int lives, int finalTime, int phase);

void changeStatisticsMap();

#endif
