#ifndef PHASE_H
#define PHASE_H

void phase1 ();

#endif
