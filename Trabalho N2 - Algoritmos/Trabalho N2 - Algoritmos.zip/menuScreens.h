#ifndef MENUSCREEN_H
#define MENUSCREEN_H

void makeScreenTextures();

void mainScreen(int selection);

void pauseScreen(int selection);

#endif
